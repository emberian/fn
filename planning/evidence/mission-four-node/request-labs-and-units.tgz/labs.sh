#!/bin/sh
# The native request verb's cases (qual-bbf52159 labs.sh) on the lane image abbd8aef.
set -u
T=/tank/fn/gates/mission-four-node-img-abbd8aef
cd $T
export FN_ACL2=/tank/fn/toolchains/w28/acl2-literal-4g FN_OPENSSL_PREFIX=/tank/fn/toolchains/openssl-3.5.8 LD_LIBRARY_PATH=/tank/fn/toolchains/openssl-3.5.8/lib PYTHONDONTWRITEBYTECODE=1
IMG=$T/build/images/abbd8aef8586d17f451010d3e2490686de8aeb95/fn-host-dtn-developer
R=/tank/fn/scratch/mission-four-node/request-labs; rm -rf $R; mkdir -p $R
sha256sum $IMG $IMG.core > $R/image.sha256
python3 tests/bp-dtn7/run_fn_dtn7_app_receipt.py --image $IMG --relays 0 --native --work $R/control > $R/control.out 2>&1; echo "control rc=$?" | tee -a $R/rcs
python3 tests/bp-dtn7/run_fn_dtn7_app_receipt.py --image $IMG --relays 1 --native --dtn7-repo /tank/fn/dtn7/repo --work $R/dtn7-carried-1 > $R/dtn7-carried-1.out 2>&1; echo "dtn7-carried-1 rc=$?" | tee -a $R/rcs
python3 tests/bp-dtn7/run_fn_dtn7_app_receipt.py --image $IMG --relays 2 --native --dtn7-repo /tank/fn/dtn7/repo --work $R/dtn7-carried-2 > $R/dtn7-carried-2.out 2>&1; echo "dtn7-carried-2 rc=$?" | tee -a $R/rcs
python3 tests/bp-dtn7/run_fn_dtn7_app_receipt.py --image $IMG --relays 1 --native --b-trusts neighbour --dtn7-repo /tank/fn/dtn7/repo --work $R/dtn7-unauthorized > $R/dtn7-unauthorized.out 2>&1; echo "dtn7-unauthorized rc=$?" | tee -a $R/rcs
echo LABS-DONE >> $R/rcs
