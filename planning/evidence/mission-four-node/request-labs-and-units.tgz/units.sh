#!/bin/sh
set -u
T=/tank/fn/gates/mission-four-node-img-abbd8aef
I=$T/build/images/abbd8aef8586d17f451010d3e2490686de8aeb95
cd $T
export FN_ACL2=/tank/fn/toolchains/w28/acl2-literal-4g FN_OPENSSL_PREFIX=/tank/fn/toolchains/openssl-3.5.8 LD_LIBRARY_PATH=/tank/fn/toolchains/openssl-3.5.8/lib PYTHONDONTWRITEBYTECODE=1
export FN_NATIVE_BP_HOST=$I/fn-host-dtn-developer FN_NATIVE_BP_NODE_HOST=$I/fn-host-dtn-developer FN_NATIVE_DEVELOPER_HOST=$I/fn-host-developer FN_NATIVE_READER_HOST=$I/fn-host-developer FN_TEST_OPENSSL=/tank/fn/toolchains/openssl-3.5.8/bin/openssl
O=/tank/fn/scratch/mission-four-node/units; rm -rf $O; mkdir -p $O
python3 -m unittest -v tests.test_bp_service_native tests.test_bp_contact_native > $O/service-contact.log 2>&1; echo "service+contact rc=$?" >> $O/rcs
python3 -m unittest -v tests.test_bp_node_native -k receipt -k request -k uncertain_transfer -k kind_eight -k unrouted -k removed_route > $O/bp-node.log 2>&1; echo "bp_node rc=$?" >> $O/rcs
echo UNITS-DONE >> $O/rcs
