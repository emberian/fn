#!/bin/sh
cd /tank/fn/scratch/harness-repair-2
M=$(cat mods.txt)
NS_TAG=fwd NS_BP_IMAGE=fn-host-dtn-developer sh run.sh $M
NS_TAG=rev NS_BP_IMAGE=fn-host-dtn-developer sh run.sh --order reverse $M
echo done > sweep.end
